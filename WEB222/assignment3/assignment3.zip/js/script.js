function myBird() {
    var birdVideo = document.getElementById("birdVideo");
    birdVideo.playbackRate = 10.0;
    birdVideo.play();
  }